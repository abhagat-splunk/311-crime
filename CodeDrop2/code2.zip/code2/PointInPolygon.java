package json.parsers;

import java.io.File;
import java.io.IOException;

import org.geotools.data.FileDataStore;
import org.geotools.data.FileDataStoreFinder;
import org.geotools.data.simple.SimpleFeatureCollection;
import org.geotools.data.simple.SimpleFeatureSource;
import org.geotools.factory.CommonFactoryFinder;
import org.geotools.factory.GeoTools;
import org.geotools.geometry.jts.ReferencedEnvelope;
import org.geotools.swing.data.JFileDataStoreChooser;
import org.opengis.filter.Filter;
import org.opengis.filter.FilterFactory2;
import org.opengis.filter.expression.Expression;

import com.vividsolutions.jts.geom.Coordinate;
import com.vividsolutions.jts.geom.GeometryFactory;
import com.vividsolutions.jts.geom.Point;

public class PointInPolygon {
  public class PointInPolygon {
    private SimpleFeatureCollection features;
    FilterFactory2 ff;
    private ReferencedEnvelope envelope;

    public static void main(String[] args) throws IOException {
      File file = null;
      FileDataStore store = FileDataStoreFinder.getDataStore(file);
      SimpleFeatureSource featureSource = store.getFeatureSource();

      PointInPolygon tester = new PointInPolygon();
      tester.setFeatures(featureSource.getFeatures());

      GeometryFactory fac = new GeometryFactory();
      for (int i = 0; i < 1000; i++) {
        double lat = (Math.random() * 180.0) - 90.0;
        double lon = (Math.random() * 360.0) - 180.0;
        Point p = fac.createPoint(new Coordinate(lat, lon));
        boolean flag = tester.isInShape(p);
      }
    }

    public PointInPolygon() {
      ff = CommonFactoryFinder.getFilterFactory2(GeoTools
          .getDefaultHints());
    }

    private void setFeatures(SimpleFeatureCollection features) {
      this.features = features;
      envelope = features.getBounds();
    }

    private boolean isInShape(Point p) {
      if (!envelope.contains(p.getCoordinate())) {
        return false;
      }
      Expression propertyName = ff.property(features.getSchema()
          .getGeometryDescriptor().getName());
      Filter filter = ff.contains(propertyName,
          ff.literal(p));
      SimpleFeatureCollection sub = features.subCollection(filter);
      if (sub.size() > 0) {
        return true;
      }
      return false;
    }
  }
}
